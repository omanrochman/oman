<?php
session_start();

$admin_user = 'rochman';
$admin_pass = 'rochman1919';

// Proses login
if (isset($_POST['login'])) {
    if ($_POST['username'] === $admin_user && $_POST['password'] === $admin_pass) {
        $_SESSION['login'] = true;
        header("Location: index.php");
        exit();
    } else {
        $_SESSION['pesan'] = "❌ Username atau Password salah!";
        $_SESSION['tipe_pesan'] = "error";
    }
}

// Proses logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

// Jika belum login tampilkan form login
if (!isset($_SESSION['login'])):
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Login Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1e3a8a, #9333ea, #2563eb);
            background-size: 300% 300%;
            animation: gradientMove 15s ease infinite;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        @keyframes gradientMove {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .login-box {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(12px);
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        .login-box h2 {
            margin-bottom: 25px;
            color: #ffffff;
            font-size: 28px;
        }

        .login-box input {
            width: 100%;
            padding: 14px;
            margin: 12px 0;
            border: none;
            border-radius: 8px;
            background: rgba(255,255,255,0.1);
            color: white;
            font-size: 16px;
            transition: 0.3s;
        }

        .login-box input:focus {
            background: rgba(255,255,255,0.2);
            outline: none;
            box-shadow: 0 0 0 2px #44c8ff;
        }

        .login-box button {
            width: 100%;
            padding: 14px;
            margin-top: 15px;
            border: none;
            border-radius: 8px;
            background-color: #44c8ff;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .login-box button:hover {
            background-color: #00d8ff;
            box-shadow: 0 0 10px rgba(0, 216, 255, 0.6);
        }

        .notif {
            padding: 12px;
            margin-top: 10px;
            border-radius: 6px;
            font-size: 14px;
            color: white;
            background: #e74c3c;
            animation: fadeIn 0.5s ease forwards;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-5px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

    <div class="login-box">
        <h2>Login Admin</h2>

        <?php if (isset($_SESSION['pesan'])): ?>
            <div class="notif"><?= $_SESSION['pesan']; unset($_SESSION['pesan']); ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="text" name="username" placeholder="Username" required autofocus>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">Masuk</button>
        </form>
    </div>

</body>
</html>
<?php
exit();
endif;

// Setelah login, koneksi database dan fungsi absensi

$koneksi = mysqli_connect("localhost", "root", "", "rochman");
if (!$koneksi) die("Koneksi gagal: " . mysqli_connect_error());

$edit = false;
function hanyaHuruf($teks) {
    return preg_match("/^[a-zA-Z\s]+$/", $teks);
}

$pesan = $_SESSION['pesan'] ?? "";
$tipe_pesan = $_SESSION['tipe_pesan'] ?? "";
unset($_SESSION['pesan'], $_SESSION['tipe_pesan']);

// Simpan data baru
if (isset($_POST['simpan'])) {
    $nama = trim($_POST['nama']);
    $status = $_POST['status'];

    if (!hanyaHuruf($nama)) {
        $_SESSION['pesan'] = "❌ Nama hanya boleh berisi huruf dan spasi!";
        $_SESSION['tipe_pesan'] = "error";
    } else {
        $cek = mysqli_query($koneksi, "SELECT * FROM absensi WHERE nama='$nama'");
        if (mysqli_num_rows($cek) > 0) {
            $_SESSION['pesan'] = "⚠️ Data dengan nama <b>$nama</b> sudah ada!";
            $_SESSION['tipe_pesan'] = "warning";
        } else {
            mysqli_query($koneksi, "INSERT INTO absensi (nama, status) VALUES ('$nama','$status')");
            $_SESSION['pesan'] = "✅ Data absensi $nama berhasil ditambahkan!";
            $_SESSION['tipe_pesan'] = "sukses";
        }
    }
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Ambil data untuk edit
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $data = mysqli_query($koneksi, "SELECT * FROM absensi WHERE id='$id'");
    $row = mysqli_fetch_assoc($data);
    $edit = true;
}

// Update data
if (isset($_POST['update'])) {
    $id = $_POST['id'];
    $nama = trim($_POST['nama']);
    $status = $_POST['status'];

    if (!hanyaHuruf($nama)) {
        $_SESSION['pesan'] = "❌ Nama hanya boleh berisi huruf dan spasi!";
        $_SESSION['tipe_pesan'] = "error";
    } else {
        $cek = mysqli_query($koneksi, "SELECT * FROM absensi WHERE nama='$nama' AND id != '$id'");
        if (mysqli_num_rows($cek) > 0) {
            $_SESSION['pesan'] = "⚠️ Data dengan nama <b>$nama</b> sudah ada!";
            $_SESSION['tipe_pesan'] = "warning";
        } else {
            mysqli_query($koneksi, "UPDATE absensi SET nama='$nama', status='$status' WHERE id='$id'");
            $_SESSION['pesan'] = "✅ Data absensi berhasil diperbarui!";
            $_SESSION['tipe_pesan'] = "sukses";
        }
    }
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}

// Hapus data
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    mysqli_query($koneksi, "DELETE FROM absensi WHERE id='$id'");
    $_SESSION['pesan'] = "🗑️ Data absensi berhasil dihapus!";
    $_SESSION['tipe_pesan'] = "warning";
    header("Location: ".$_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Absensi Pegawai</title>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(45deg, #44c8ff, #3b82f6, #8b5cf6, #d946ef);
            background-size: 400% 400%;
            animation: gradientBackground 10s ease infinite;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px 20px;
            min-height: 100vh;
            margin: 0;
            color: white;
            position: relative;
        }
        @keyframes gradientBackground {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }
        .container {
            background: rgba(20, 20, 20, 0.8);
            max-width: 900px;
            width: 100%;
            border-radius: 20px;
            padding: 40px 50px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
            position: relative;
        }
        h2 {
            color: #00d8ff;
            font-weight: bold;
            letter-spacing: 1px;
            margin-bottom: 30px;
        }
        form {
            background: #1e1e2f;
            padding: 30px 35px;
            border-radius: 20px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            margin-bottom: 40px;
            transition: box-shadow 0.3s ease;
        }
        form:hover {
            box-shadow: 0 0 15px rgba(0, 216, 255, 0.5);
        }
        input, select, button {
            width: 100%;
            padding: 15px;
            margin-top: 10px;
            border-radius: 8px;
            border: 1px solid #ddd;
            background: #333;
            color: white;
            font-size: 16px;
            outline: none;
        }
        button {
            background: #44c8ff;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        button:hover {
            background: #00d8ff;
        }
        .notif {
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            color: white;
            font-weight: 600;
        }
        .notif.error { background: #e74c3c; }
        .notif.warning { background: #f39c12; }
        .notif.sukses { background: #2ecc71; }

        table {
            width: 100%;
            border-collapse: collapse;
            color: #fff;
            font-size: 16px;
        }
        th, td {
            border: 1px solid #444;
            padding: 12px 15px;
            text-align: left;
        }
        th {
            background: #1f2937;
        }
        tr:nth-child(even) {
            background: #2d3748;
        }
        a {
            color: #44c8ff;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s ease;
        }
        a:hover {
            color: #00d8ff;
            text-decoration: underline;
        }

        /* Logout button */
        .logout-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #e74c3c;
            color: white;
            padding: 10px 20px;
            border-radius: 12px;
            font-weight: bold;
            text-decoration: none;
            box-shadow: 0 5px 15px rgba(231, 76, 60, 0.6);
            transition: background 0.3s ease;
            z-index: 1000;
        }
        .logout-btn:hover {
            background: #c0392b;
            box-shadow: 0 5px 20px rgba(192, 57, 43, 0.8);
        }
    </style>
</head>
<body>

<a href="?logout=true" class="logout-btn" title="Logout">Keluar</a>

<div class="container">
    <h2>Absensi Pegawai</h2>
    <?php if ($pesan): ?>
        <div class="notif <?= $tipe_pesan ?>"><?= $pesan ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="nama" placeholder="Nama Pegawai" value="<?= $edit ? htmlspecialchars($row['nama']) : '' ?>" required>
        <select name="status">
            <option value="Hadir" <?= $edit && $row['status'] == 'Hadir' ? 'selected' : '' ?>>Hadir</option>
            <option value="Izin" <?= $edit && $row['status'] == 'Izin' ? 'selected' : '' ?>>Izin</option>
            <option value="Alpa" <?= $edit && $row['status'] == 'Alpa' ? 'selected' : '' ?>>Alpa</option>
        </select>
        <?php if ($edit): ?>
            <input type="hidden" name="id" value="<?= $row['id'] ?>">
            <button type="submit" name="update">Update</button>
        <?php else: ?>
            <button type="submit" name="simpan">Simpan</button>
        <?php endif; ?>
    </form>

    <h3>Daftar Absensi</h3>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $result = mysqli_query($koneksi, "SELECT * FROM absensi ORDER BY id DESC");
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)):
            ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= $row['status'] ?></td>
                <td>
                    <a href="?edit=<?= $row['id'] ?>">Edit</a> |
                    <a href="?hapus=<?= $row['id'] ?>" onclick="return confirm('Hapus data?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
            <?php if(mysqli_num_rows($result) == 0): ?>
            <tr><td colspan="4" style="text-align:center; color:#999;">Belum ada data absensi.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>